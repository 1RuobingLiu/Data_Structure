//Ruobing Liu
//2022F CS 570-WS
/**
 * 
 * implement a number of methods for a class Complexity. These methods 
should be implemented using for loops, as seen in class (except for the extra-credit one). In 
addition, each of these methods should print out the value of an accumulator that counts the 
number of “operations” performed. The notion of “operation” should be taken loosely; the idea is 
that if you are requested to implement a method of time complexity O(n), then it should print out 
values from 1 to n (or close enough). 
 *
 */
public class Complexity {
	private static int counter6=0;
	//Time complexity O(n^2).
	public static void method1(int n) { 
		int counter=0;
		for (int i=0; i<n; i++) {
			for (int j=0;j<n;j++) {
				System.out.println("Operation "+counter); 
				counter++;
			}
		}
	}
	
	//Time complexity O(n^3).
	public static void method2(int n) {
		int counter=0;
		for (int i=0; i<n; i++) {
			for (int j=0;j<n;j++) {
				for (int k=0; k<n; k++) {
					System.out.println("Operation "+counter); 
					counter++;
				}
			}
		}
	}
	
	//Time complexity O(logn).
	public static void method3(int n) {
		int counter=0;
		for (int i=1; i<n; i=i*2) {
			System.out.println("Operation "+counter); 
			counter++;
		}
	}
	
	//Time complexity O(nlogn).
	public static void method4(int n) {
		int counter=0;
		for (int i=1; i<n; i=i*10) {
			for (int j=1;j<=n;j++) {
				System.out.println("Operation "+counter); 
				counter++;
			}
		}
	}
	
	//Time complexity O(loglogn).
	public static void method5(int n) {
		int counter=0;
		for (int i=2; i<n; i=i*i) {
			System.out.println("Operation "+counter); 
			counter++;
		}
	}
	
	//Time complexity O(2^n).Recursion.
	public static int method6(int n) {
		if (n==0) {
			System.out.println("Operation " + counter6);
			counter6++;
		}
		else {
			method6(n-1); 
			method6(n-1);	
		}
		return counter6;
	}
}
